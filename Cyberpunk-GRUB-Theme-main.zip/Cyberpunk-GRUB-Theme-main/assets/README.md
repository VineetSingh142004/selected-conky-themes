#Assets

Font Used : Blender Pro Book by Nik Thoenen . Font made from [oNline Web Fonts](http://www.onlinewebfonts.com) is licensed by CC BY 3.0

Images from Cyberpunk 2077 Official Website https://www.cyberpunk.net, [Unsplash](https://unsplash.com/photos/pVq6YhmDPtk)

Icons: Modified Version of Icons from [Breeze](https://github.com/gustawho/grub2-theme-breeze) and Tela themes 


